import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("b00ea2a7-a2b4-40c6-a403-423495ea80a2")
public class partieRésidence {
    @objid ("7409855f-69e1-471e-9766-6695bfb958b7")
    public String idPartie;

    @objid ("6f967767-71f0-4df9-a5fe-03c233364b6c")
    public boolean disponible;

    @objid ("b18d8ab1-6798-4579-892f-b62661157ea6")
    public Résidence composer;

    @objid ("980c97c7-ed6f-4a89-9df1-0e2ee0305453")
    public void getDispo() {
    }

    @objid ("70ece65a-9858-4665-9f77-9a79f569b1b6")
    public void calculerTarif() {
    }

}
