import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("ca75ad81-1037-462d-a32f-acd3b598a8b2")
public class paiement {
    @objid ("b24fb481-0c08-484c-ad29-cb204b879d2f")
    public String idPaiement;

    @objid ("be8674ed-de86-4956-ac4f-e76c1d8b4317")
    public String date;

    @objid ("d7769dc8-72e8-440f-88e7-e7609609892b")
    public void payerTous() {
    }

    @objid ("f8ee9ed8-7f14-498f-a70d-ef28d72a9a7f")
    public void payerPartie() {
    }

}
