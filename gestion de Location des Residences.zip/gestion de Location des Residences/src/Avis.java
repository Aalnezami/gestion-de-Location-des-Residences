import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("8a954cf4-4b95-4e6b-82e9-6a6e50ff32cc")
public class Avis {
    @objid ("5b608ac5-d758-4d68-b1d3-4dcc32a58c5f")
    public String idAvis;

    @objid ("34305dd6-6411-4a66-8f75-e70537456009")
    public String creator;

    @objid ("528772e5-134d-4375-94ab-23c516e9970d")
    public String contenu;

    @objid ("92cfdd92-8ace-4cf9-9701-35a642a17f36")
    public void afficher() {
    }

}
